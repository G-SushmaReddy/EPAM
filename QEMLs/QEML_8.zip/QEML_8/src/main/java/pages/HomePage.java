package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage {

    @FindBy(name = "search")
    private WebElement searchBar;

    @FindBy(tagName = "h2")
    private WebElement headingElement;

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void openApplication(){
        driver.get("https://tutorialsninja.com/demo/");
    }

    public void enterSearchText(String searchText){
        wait.until(ExpectedConditions.visibilityOf(searchBar));
        searchBar.sendKeys(searchText);
        searchBar.sendKeys(Keys.ENTER);
    }

    public boolean validateHeading(){
        wait.until(ExpectedConditions.visibilityOf(headingElement));
        return headingElement.getText().equals("Products meeting the search criteria");
    }
}