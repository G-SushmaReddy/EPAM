package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

public class DriverFactory {

    private static ThreadLocal<String> browserName = new ThreadLocal<>();
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    public static WebDriver getDriver(){
        return driver.get();
    }

    public static void setBrowser(String browser){
        browserName.set(browser);
    }

    public static String getBrowser(){
        return browserName.get();
    }

    public static void setDriver() throws Exception{
        WebDriver driverInstance = null;

        switch(getBrowser()){
            case "chrome" -> {
                ChromeOptions chromeOptions = new ChromeOptions();
                driverInstance = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), chromeOptions);
            }

            case "firefox" -> {
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                driverInstance = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), firefoxOptions);
            }

            case "edge" -> {
                EdgeOptions edgeOptions = new EdgeOptions();
                driverInstance = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), edgeOptions);
            }
        }
        driver.set(driverInstance);
    }

    public static void quitDriver(){
        if(driver.get() != null){
            driver.get().quit();
            driver.remove();
            browserName.remove();
        }
    }
}
