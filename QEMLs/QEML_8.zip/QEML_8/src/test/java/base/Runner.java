package base;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/features/ui",
        glue = {"uistepdefinitions", "base"},
        plugin = {"pretty", "html:target/cucumber-reports"}
)
public class Runner extends AbstractTestNGCucumberTests {
}
