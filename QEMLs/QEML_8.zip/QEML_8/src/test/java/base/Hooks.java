package base;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.testng.ITestContext;
import org.testng.Reporter;
import utils.DriverFactory;

public class Hooks {

    @Before
    public void setup() throws Exception{

        ITestContext context = Reporter.getCurrentTestResult().getTestContext();
        String browser = context.getCurrentXmlTest().getParameter("browser");
        DriverFactory.setBrowser(browser);
        DriverFactory.setDriver();
    }

    @After
    public void tearDown(){
        DriverFactory.quitDriver();
    }
}
