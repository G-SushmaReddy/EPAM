package uiStepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import pages.HomePage;
import utils.DriverFactory;

public class StepDefinitions {

    private WebDriver driver;
    private HomePage homePage;

    public StepDefinitions(){

    }

    @Given("I open the application")
    public void openApplication(){
        driver = DriverFactory.getDriver();
        homePage = new HomePage(driver);
        homePage.openApplication();
    }

    @When("I search for {string}")
    public void search(String product){
        homePage.enterSearchText(product);
    }

    @Then("I should see search results for {string}")
    public void searchResult(String result){
        Assert.assertTrue(homePage.validateHeading());
    }
}
