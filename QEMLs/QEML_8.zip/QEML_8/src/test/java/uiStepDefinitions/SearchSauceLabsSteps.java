package uiStepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class SearchSauceLabsSteps {

    private WebDriver driver;

    @Given("the user is on Google search page")
    public void userOnGoogleSearchPage() throws MalformedURLException {
        ChromeOptions options = new ChromeOptions();

        Map<String, Object> sauceOptions = new HashMap<>();
        sauceOptions.put("name", "Google search test - chrome");
        sauceOptions.put("build", "001");

        options.setCapability("sauce:options", sauceOptions);
        options.setPlatformName("Windows 11");
        options.setBrowserVersion("latest");
        driver = new RemoteWebDriver(
                new URL("https://oauth-gottiparthy_rishitha-2a469:5975b62f-1b79-4f77-a42b-df56b41378ab@ondemand.eu-central-1.saucelabs.com:443/wd/hub"), options
        );
        driver.get("https://www.google.com");
    }

    @When("the user searches for {string}")
    public void search(String search){
        driver.findElement(By.name("q")).sendKeys(search, Keys.ENTER);
    }

    @Then("the results page should appear")
    public void viewResults(){
        System.out.println(driver.getTitle());
        Assert.assertTrue(driver.getTitle().contains("Sauce"));
        driver.quit();
    }
}
