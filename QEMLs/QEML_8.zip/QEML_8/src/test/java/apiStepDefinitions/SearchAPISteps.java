package apiStepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

import static io.restassured.RestAssured.given;

public class SearchAPISteps {

    private Response response;

    @Given("a search API")
    public void searchAPI(){
        RestAssured.baseURI = "https://dummyjson.com";
    }

    @When("I search for a {string}")
    public void searchProduct(String product){
        response = given()
                .queryParam("q", product)
                .when()
                .get("/products/search")
                .then()
                .extract().response();
    }

    @Then("the status code should be {int}")
    public void validateStatusCode(int statusCode){
        Assert.assertEquals(response.statusCode(), statusCode);
    }

    @And("the response should contain results from {string}")
    public void validateResponse(String expected){
        String body = response.asString().toLowerCase();
        Assert.assertTrue(body.contains(expected.toLowerCase()));
    }
}
