Feature: Search API testing

  Scenario Outline: Search products
    Given a search API
    When I search for a "<product>"
    Then the status code should be 200
    And the response should contain results from "<product>"

    Examples:
      | product |
      | Laptop  |
      | Phone   |
      | Watch   |