Feature: Sauce labs search

  Scenario: Search for Sauce labs
    Given the user is on Google search page
    When the user searches for "Sauce Labs"
    Then the results page should appear