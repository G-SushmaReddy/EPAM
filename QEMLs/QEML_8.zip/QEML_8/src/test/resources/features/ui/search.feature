Feature: Product Search

  Scenario Outline: Search for a product
    Given I open the application
    When I search for "<product>"
    Then I should see search results for "<product>"

    Examples:
      | product |
      | Apple   |
      | Samsung |
